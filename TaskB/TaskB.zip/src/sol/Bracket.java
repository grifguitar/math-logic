package sol;

public enum Bracket implements BracketOrOperation {
    OPEN()
}