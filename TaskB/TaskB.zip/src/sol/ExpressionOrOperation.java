package sol;

public interface ExpressionOrOperation {
}
