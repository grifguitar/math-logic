package sol;

public interface BracketOrOperation {
}
